<?php include "includes/header.php";?>
<br>
<?php
include "includes/config.php";

if(isset($_POST['submit'])){
	$matric = $_POST['matric'];
	$password = $_POST['password'];
	
	$query= "SELECT matric, password from graduates where matric ='$matric' and password ='$password'";
	$query_run=mysqli_query($connection,$query);
	
	if ($query_run -> num_rows > 0){
		session_start();
		$_SESSION['matric'] = $matric;
		header("location:dashboard.php");
		
	}else{

		echo "Sorry you have to register first";
	}
	
}else{
	
}

?>


<body style = "background:url('images/backgroundlecture4.png'); font-family:candara;">
<div style ="height:475px; width:100%;">
<center>
  <div>
  <fieldset style ="background:gray; height:; width:30%; border-radius:15px;">
  LOGIN
   <form action ="" method ="post">
	<label for "matric"></label><br>
	<input name ="matric" type ="text" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Matric Number"></input><br>
	
	<label for "password"></label><br>
	<input name ="password" type ="password" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Pasword"></input><br>
	<br>
	<button name = "submit" value ="Sign In">Sign In</button>
	</form>
	</fieldset>
  </div>
</center>
</div>
<br>
</body>

<?php include "../includes/footer.php";?>
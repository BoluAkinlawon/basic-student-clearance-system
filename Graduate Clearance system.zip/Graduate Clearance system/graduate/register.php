<?php include "includes/header.php";?>
<hr>
<?php
include "includes/config.php";
if(isset($_POST['submit'])){
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$username = $_POST['username'];
	$email = $_POST['email'];
	$matric = $_POST['matric'];
	$password = $_POST['password'];
	
	$query = "INSERT INTO graduates(firstname, lastname, username, email, matric, password) VALUES('$firstname', '$lastname', '$username', '$email', '$matric','$password')";
	$query_run = mysqli_query($connection, $query);
	
	if($query_run){
		header("location:login.php");
		
	}else{
		echo"Sorry there was an error";
	}
	
}


?>


<body style = "background:url("");">
<div style ="height:475px; width:100%;">
<center>
  <div>
  <fieldset style ="background:gray; height:; width:30%; border-radius:15px;">
    <form action = "" method ="post">
	<label for "firstname"></label><br>
	<input name ="firstname" type ="text" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Firstname"></input><br>
	
	<label for "lastname"></label><br>
	<input name ="lastname" type ="text" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Lastname"></input><br>
	
	<label for "username"></label><br>
	<input name ="username" type ="text" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Username"></input><br>
	
	<label for "email"></label><br>
	<input name ="email" type ="email" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Email"></input><br>
	
	<label for "matric"></label><br>
	<input name ="matric" type ="text" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Matric Number"></input><br>
	
	<label for "password"></label><br>
	<input name ="password" type ="password" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Pasword"></input><br>
	<br>
	<button name = "submit">Sign Up</button>
	</form>
	</fieldset>
  </div>
</center>
</div>
<br>
</body>
<?php include "includes/footer.php";?>
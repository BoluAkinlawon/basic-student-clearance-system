<?php include "../includes/header.php";?>
<br>
<hr>
<?php
session_start();
if(!isset($_SESSION['matric'])){
	header("location:login.php");
	echo "You are not logged in to see content";
	}else{
		$session =$_SESSION['matric'];
		echo "". $session."</br>";
		
	
}
?>

<head>
<style>
body {background:  url("images/backgroundlecture4.png");
      background-repeat: no-repeat;
      background-size:145%;
      color: ;
      font-size: 14px;
      font-size: 14px;
      font-family: Candara;
      margin: 0;
      padding: 0;
      text-align: center;}
</style>
</head>
<body>

<?php
if(isset($_POST['logout'])){
	session_destroy();
	header("location:login.php");
}
 echo "<p style ='margin:5px;' align =right>"."<a href =  style ='background:white;'>Change password</a>"."</br>";
 //echo "<p style ='margin:5px;' align =right>".$_SESSION['phone']."</br>";

?>

<div style ="text-align:right;">
<form action ="" method ="post">
<input type= "submit" name ="logout" value ="Log Out" align ="right"></input>
</form>


</div>
<center>
  <div style ="height:50px; background-color:lightblue; width:30%;" align ="center" "border-radius:5px; ">

  
  <a href ="../index.php" style ="background-color: lightblue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block; font-size: 16px;">Home</a>
  
<a href ="register.php" style ="background-color: gray;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block; font-size: 16px; height:50px;">Register</a></li>
  
 <a href ="login.php" style ="background-color: lightgreen;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block; font-size: 16px; height:50px;">Login</a></li>
  
  <a href ="logout.php" style ="background-color: lightblue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block; font-size: 16px;">Log Out</a> 
  

  </div>
    <div style ="height:35px; background-color:white; width:95%;" align ="center">
	
  </center>
  <center>
<div>
<fieldset style ="width:80%; height:auto; border-radius:5px; text-border:1px solid blue; background:lightblue;">
<?php
include "includes/config.php";

$query ="SELECT firstname, lastname from graduates where matric ='$session'";
$query_run = mysqli_query($connection, $query);

if($query_run -> num_rows > 0){
      while($row = $query_run -> fetch_assoc()){
      echo "<p align =left>"."Name" .": ". $row["firstname"]." ".$row['lastname']."</br>";
	  echo "<p align =left>"."User Type: User". "</br>";
	 
      }
        
  }
  else {
      echo "0 result";
  }

  $connection -> close();

?>

<?php
 if(isset($_POST['logout'])){
	 session_destroy();
	 header("location:login.php");
	 
 }

?>
<form action ="" method ="post" align ="left">
<button type ="submit" name ="logout" style ="border-radius:5px; text-border: 1px solid brown; background:lightgreen;">Logout</button>
</form>
</fieldset>
</div>
</center>
<center>
  <div style ="height:420px; width:90%;">
  <br>
  <button><a href="data.php"><p align ="left">View/Edit Your Profile</p></a></button><br>
  <p align ="left"></p><br>
  
  <button><a href="lectures/index.php"><p align ="left">Edit Your Profile</p></a></button><br>
  <p align ="left"></p><br>
  
  <button><a href="clearance.php"><p align ="left">Print Clearance Form</p></a></button><br>
  <p align ="left"></p><br>
  <p align ="left"></p><br>
  </div>
</center> 
  
</body>

<?php include "includes/footer.php";?>
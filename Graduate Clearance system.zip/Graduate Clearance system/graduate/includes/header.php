<html>
<head>
<style>
 body{
	 font-family:Candara;
 }
</style>
 <title>Automated Graduate Database</title>
 <meta content="text/html; charset=ISO-8859-1" http-equiv="content-type" />
     <meta name="viewport" content="width=100% height =100%,initial-scale=0.7,maximum-scale=1.0,user-scalable=no">
     <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
     <meta name="HandheldFriendly" content="true">
	   <link rel ="stylesheet" type ="text/css" href ="style.css">
	   <link rel ="shortcut-icon" href ="images/logo.ico"/>
</head>
<body style ="height:540px; width:100%; background:gray;">
   <div style ="height:569px; width:100%; background:gray;">
   <center>
   <div style ="width:85%; height:65px; background:lightblue;">Ken Saro Wiwa Polytechnic Graduate Database<br>
   
   <a href ="../index.php" style ="background-color: lightblue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Home</a>
  
  <a href ="news.php" style ="background-color: lightblue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">News</a> 
  
  <a href ="forum.php" style ="background-color: lightblue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Forum</a>
  
  <a href ="register.php" style ="background-color: lightblue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;"> Register </a>
  
  <a href ="dashboard.php" style ="background-color: lightgreen;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Login</a></li>
  
   
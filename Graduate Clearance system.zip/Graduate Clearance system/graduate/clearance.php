

<br>
<hr>
<?php
session_start();
if(!isset($_SESSION['matric'])){
	header("location:login.php");
	echo "You are not logged in to see content";
	}else{
		$session =$_SESSION['matric'];
		echo "". $session."</br>";
		
	
}
?>
<head>
<style>
body {background:  url("images/backgroundlecture4.png");
      background-repeat: no-repeat;
      background-size:145%;
      color: ;
      font-size: 14px;
      font-size: 14px;
      font-family: Candara;
      margin: 0;
      padding: 0;
      text-align: center;}
</style>
</head>

<body>
<FORM action ="" method ="post">
<button name ="print" align ="center">Print</button>
</FORM>
<?php include "includes/config.php";
if(isset($_POST['print'])){
	$session =$_SESSION['matric'];
	
	$query = "SELECT firstname, lastname FROM graduates where matric ='$session' and approved='1'";
	$result = $connection->query($query);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<div style =background:lightgreen font-size:16px>" ."<img src = images/ksp.jpg style =height:60px; width:60px; background:lightgreen;></img>"."</br>"."This is to certify that ". $row["firstname"] ." ". $row["lastname"]." has been sucessfully cleared for graduation"."</br>"."</br>";
echo  "................... " ."</br> "." Vice Chancellor Signature"."</br>"."</div>";
}
}
else {
	echo"Sorry you have not been cleared for graduation";
}
}
$connection->close();

?>
<script type ="text/javascript">
alert('Use CTRL+P to print your clearance form');
</script>
</body>
<div style ="background:lightgreen; height:400px;"></div>
<?php include "includes/footer.php";?>
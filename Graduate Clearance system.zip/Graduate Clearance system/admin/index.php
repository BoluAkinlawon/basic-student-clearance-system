<?php include "includes/header.php";?>
<head>
<style>
body {background:  url("images/backgroundlecture4.png");
      background-repeat: no-repeat;
      background-size:145%;
      color: ;
      font-size: 14px;
      font-size: 14px;
      font-family: Candara;
      margin: 0;
      padding: 0;
      text-align: center;
	  }
	  button{
		 text-decoration:none;
	 }
</style>
</head>
<br><br>

<button style = ""><a href="data.php"><p align ="left">See Graduate details</p></a></button><br>
  <p align ="left"></p><br>
 <div style ="height:400px; width:100%;"></div>
<?php include "includes/footer.php";?>
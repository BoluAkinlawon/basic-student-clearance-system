<html>
<center>
<footer>
   <div style ="width:100%; height:50px; background:lightblue;"></div>
   <footer>
</center>   

</html>
<html>
<head>
 <title>Automated Graduate Database</title>
 <meta content="text/html; charset=ISO-8859-1" http-equiv="content-type" />
     <meta name="viewport" content="width=100% height =100%,initial-scale=0.7,maximum-scale=1.0,user-scalable=no">
     <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
     <meta name="HandheldFriendly" content="true">
	   <link rel ="stylesheet" type ="text/css" href ="style.css">
	   <link rel ="shortcut-icon" href ="images/logo.ico"/>
</head>
<body style ="height:540px; width:100%; background:gray;">
   <div style ="height:569px; width:100%; background:gray;">
   <center>
<div style ="width:85%; height:58px; background:lightblue;"><img src ="images/logo.jpg" style ="height:50px; width:50px;" align ="center"></img>Delta State Polytechnic Clearance<br>
   
   <a href ="index.php" style ="background-color: lightblue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Home</a>
 
  
  <a href ="dashboard.php" style ="background-color: lightgreen;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Login</a></li>
  
   
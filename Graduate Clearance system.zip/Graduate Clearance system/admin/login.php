<?php include "includes/header.php";?>
<br>
<?php
include "includes/config.php";

if(isset($_POST['submit'])){
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	$query= "SELECT username, password from admin where username ='$username' and password ='$password'";
	$query_run=mysqli_query($connection,$query);
	
	if ($query_run -> num_rows > 0){
		session_start();
		$_SESSION['username'] = $username;
		header("location:dashboard.php");
		
	}else{

		echo "Sorry you have to register first";
	}
	
}else{
	
}

?>
<head>
<style>
body {background:  url("images/backgroundlecture4.png");
      background-repeat: no-repeat;
      background-size:145%;
      color: ;
      font-size: 14px;
      font-size: 14px;
      font-family: Candara;
      margin: 0;
      padding: 0;
      text-align: center;}
</style>
</head>


<body style = "background:url('images/backgroundlecture4.png'); font-family:candara;">
<div style ="height:475px; width:100%;">
<center>
  <div>
  <br>
  <fieldset style ="background:gray; height:; width:30%; border-radius:15px;">
  LOGIN
   <form action ="" method ="post">
	<label for "username"></label><br>
	<input name ="username" type ="text" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Username"></input><br>
	
	<label for "password"></label><br>
	<input name ="password" type ="password" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Pasword"></input><br>
	<br>
	<button name = "submit" value ="Sign In">Sign In</button>
	</form>
	</fieldset>
  </div>
</center>
</div>
<br>
</body>

<?php include "../includes/footer.php";?>
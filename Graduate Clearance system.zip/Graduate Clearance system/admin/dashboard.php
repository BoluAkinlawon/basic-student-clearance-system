<?php include "includes/header.php";?>

<head>
<style>
body{
	font-family:Candara;
}
</style>


</head>

<?php
if(isset($_POST['logout'])){
	session_destroy();
	header("location:login.php");
}
 echo "<p style ='margin:5px;' align =right>"."<a href =  style ='background:white;'>Change password</a>"."</br>";
 //echo "<p style ='margin:5px;' align =right>".$_SESSION['phone']."</br>";

?>

<div style ="text-align:right;">
<form action ="" method ="post">
<input type= "submit" name ="logout" value ="Log Out" align ="right"></input>
</form>
</div>

<center>
  <div style ="height:520px; width:90%;">
  <br>
  <button><a href="data.php"><p align ="left">View Graduates</p></a></button><br>
  <p align ="left"></p><br>
  
  <p align ="left"></p><br>
  </div>
</center> 

<?php include "includes/footer.php";?>
create table graduate and import the graduate.sql file
admin login: username:admin password:admin